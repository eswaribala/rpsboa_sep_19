package com.boa.kycconfigclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KycconfigclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycconfigclientApplication.class, args);
	}

}
