package com.boa.kycprocess.configurations;

import java.util.List;

public interface TransactionData {

	List getAllTransactions();
}
