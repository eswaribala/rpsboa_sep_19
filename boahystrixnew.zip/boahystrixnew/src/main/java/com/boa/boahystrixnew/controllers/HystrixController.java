package com.boa.boahystrixnew.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HystrixController {

	@Autowired
	private HystixDelegate hystrixDelegate;
	
	@GetMapping("/hystrixgetCustomerById/{id}")
	public String getCustomerById(@PathVariable("id") int id )
	{
		return this.hystrixDelegate.handleRequest(id);
		
	}
	
}
